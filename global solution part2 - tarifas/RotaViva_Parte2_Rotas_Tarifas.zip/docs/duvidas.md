Nenhuma dúvida registrada.
